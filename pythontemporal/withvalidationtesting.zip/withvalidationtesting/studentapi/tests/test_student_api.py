from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)


def test_create_student():
    payload = {
        "name": "Alice",
        "age": 25,
        "email": "alice@example.com"
    }
    response = client.post("/students/", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Alice"
    assert data["age"] == 25
    assert data["email"] == "alice@example.com"


def test_get_students():
    response = client.get("/students/")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)

def test_get_student_by_id():
    response = client.get("/students/1")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Alice"
    assert data["age"] == 25
    assert data["email"] == "alice@example.com"

def test_update_student():
    payload = {
        "name": "Alice Updated",
        "age": 26,
        "email": "alice.updated@example.com"
    }
    response = client.put("/students/1", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Alice Updated"
    assert data["age"] == 26
    assert data["email"] == "alice.updated@example.com"

def test_delete_student():
    response = client.delete("/students/1")
    assert response.status_code == 200
    data = response.json()
    assert data["detail"] == "Student deleted successfully"