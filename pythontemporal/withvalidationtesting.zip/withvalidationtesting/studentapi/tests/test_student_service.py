from unittest.mock import MagicMock
from app.schemas.student_schema import StudentCreate

from app.services.student_service import StudentService
def test_get_all_student():
    db = MagicMock()

    StudentService.get_all_students(db)
    db.query().assert_called()

def test_create_student():
    db = MagicMock()
    student_data = StudentCreate(
        name="Alice",
        age=25,
        email="alice@example.com"
    )
    StudentService.create_student(db, student_data)
    db.add.assert_called()
    db.commit.assert_called()