from fastapi import APIRouter

from app.services.s3_service import (
    S3Service
)

router = APIRouter(
    prefix="/s3",
    tags=["Amazon S3"]
)

@router.get("/files")
async def get_files():

    return S3Service.list_files()