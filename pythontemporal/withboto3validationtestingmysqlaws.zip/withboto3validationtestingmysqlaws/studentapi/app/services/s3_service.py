from app.aws.boto3_client import s3_client
from app.config.settings import S3_BUCKET

class S3Service:

    @staticmethod
    def upload_file(
        file_path,
        file_name
    ):

        s3_client.upload_file(
            file_path,
            S3_BUCKET,
            file_name
        )

        return {
            "message":
            "File Uploaded Successfully"
        }

    @staticmethod
    def list_files():

        response = s3_client.list_objects_v2(
            Bucket=S3_BUCKET
        )

        return response.get(
            "Contents",
            []
        )