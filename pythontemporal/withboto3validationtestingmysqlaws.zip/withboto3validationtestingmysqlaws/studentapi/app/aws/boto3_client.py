import boto3
from app.config.settings import *

session = boto3.Session(
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    region_name=AWS_REGION
)

s3_client = session.client("s3")

dynamodb = session.resource(
    "dynamodb"
)

lambda_client = session.client(
    "lambda"
)