from pydantic import BaseModel
from pydantic import Field
from pydantic import EmailStr
from pydantic import field_validator

class StudentCreate(BaseModel):
    name: str = Field(
        ...,
        min_length=3,
        max_length=10,
        description="The name of the student (3-10 characters)"
    )
    age: int= Field(
        ...,
        ge=18,
        le=60,
        description="The age of the student (18-60 years)"
    )
    email: str = EmailStr

    @field_validator('name')
    @classmethod
    def validate_name(cls, value):
        if not value.isalpha():
            raise ValueError("Name must contain only alphabetic characters")
        return value


class StudentResponse(BaseModel):
    id: int
    name: str
    age: int
    email: EmailStr

    class Config:
       from_attributes = True